import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# ===== 設定中文字體 =====
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei'] 
plt.rcParams['axes.unicode_minus'] = False 

# 原始數據
data = {
    10.0: [11, 9, 9, 10],
    5.0: [22, 21, 28, 22],
    2.5: [68, 72, 61, 64]
}

# 展開數據並直接轉換為倒數 (1/t)
x_flat = []
y_inv_flat = []
for c, vals in data.items():
    for v in vals:
        x_flat.append(c)
        y_inv_flat.append(1/v)

X = np.array(x_flat).reshape(-1, 1)
Y_inv = np.array(y_inv_flat)

# 線性回歸
model = LinearRegression()
model.fit(X, Y_inv)
a, b = model.coef_[0], model.intercept_
r2 = r2_score(Y_inv, model.predict(X))

# 繪圖
plt.figure(figsize=(8, 6), dpi=100)

# 1. 繪製所有原始數據點 (1/t)
plt.scatter(X, Y_inv, color='royalblue', edgecolors='black', s=50, label='實驗觀測值 (1/t)')

# 2. 繪製擬合直線
x_range = np.linspace(0, 12, 100).reshape(-1, 1)
y_range = model.predict(x_range)
plt.plot(x_range, y_range, color='crimson', linewidth=2, label='線性回歸趨勢')

# 標題與標籤
plt.title('雙氧水濃度與反應速率 (1/t) 之線性關係', fontsize=15, fontweight='bold')
plt.xlabel('H$_2$O$_2$ 濃度 (%)', fontsize=12)
plt.ylabel('反\n應\n速\n率\n(1/秒)', fontsize=12, rotation=0, labelpad=30, va='center')

# 方程式與 R² 文字框
equation_text = f'$y = {a:.4f}x + {b:.4f}$\n$R^2 = {r2:.4f}$'
plt.gca().text(0.05, 0.92, equation_text, transform=plt.gca().transAxes,
               fontsize=13, ha='left', va='top', 
               bbox=dict(boxstyle='round,pad=0.5', facecolor='wheat', alpha=0.3))

# 設定座標軸
plt.xlim(0, 12)
plt.ylim(0, max(y_inv_flat) * 1.2)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(loc='lower right')

plt.tight_layout()
plt.show()